
import React, { useState, useEffect } from 'react';
import { ARTISTS } from '../constants';

const HeroCarousel: React.FC = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % ARTISTS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative h-[400px] w-full overflow-hidden rounded-3xl group mb-12 shadow-2xl">
      {ARTISTS.map((artist, i) => (
        <div 
          key={artist.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${i === index ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        >
          <img 
            src={artist.photo} 
            alt={artist.name} 
            className="w-full h-full object-cover transform scale-105 group-hover:scale-110 transition-transform duration-7000"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          <div className="absolute bottom-12 left-12">
            <span className="bg-violet-600 text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-widest mb-4 inline-block">Featured Artist</span>
            <h2 className="text-6xl font-black text-white mb-2 drop-shadow-2xl">{artist.name}</h2>
            <p className="text-gray-300 text-lg flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              {artist.followers.toLocaleString()} Monthly Listeners
            </p>
            <div className="mt-6 flex gap-4">
               <button className="px-8 py-3 bg-white text-black font-bold rounded-full hover:bg-gray-200 transition-colors shadow-lg shadow-white/10">Listen Now</button>
               <button className="px-8 py-3 glass text-white font-bold rounded-full hover:bg-white/10 transition-colors">Follow</button>
            </div>
          </div>
        </div>
      ))}
      
      {/* Pagination dots */}
      <div className="absolute bottom-6 right-12 flex gap-2">
        {ARTISTS.map((_, i) => (
          <div 
            key={i} 
            className={`h-1 rounded-full transition-all duration-300 ${i === index ? 'w-8 bg-violet-500' : 'w-2 bg-white/20'}`} 
          />
        ))}
      </div>
    </div>
  );
};

export default HeroCarousel;
