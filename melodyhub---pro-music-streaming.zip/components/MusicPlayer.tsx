
import React, { useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Download, Heart, Share2, Info } from 'lucide-react';
import { Song, UserAccountType } from '../types';

interface MusicPlayerProps {
  song: Song | null;
  accountType: UserAccountType;
  onUpgrade: () => void;
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ song, accountType, onUpgrade }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(35);

  if (!song) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 glass-dark border-t border-white/10 p-4 z-50 transition-all duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Song Info */}
        <div className="flex items-center gap-4 w-1/3">
          <img src={song.cover} alt={song.title} className="w-14 h-14 rounded-lg shadow-lg border border-white/10" />
          <div className="hidden sm:block overflow-hidden">
            <h4 className="font-bold truncate text-white">{song.title}</h4>
            <p className="text-sm text-gray-400 truncate">{song.artist}</p>
          </div>
          <Heart className="w-5 h-5 text-gray-400 hover:text-red-500 cursor-pointer transition-colors" />
        </div>

        {/* Controls */}
        <div className="flex flex-col items-center w-1/3 gap-2">
          <div className="flex items-center gap-6">
            <SkipBack className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer" />
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 transition-transform"
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-black" /> : <Play className="w-5 h-5 fill-black ml-1" />}
            </button>
            <SkipForward className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer" />
          </div>
          <div className="w-full flex items-center gap-2 group">
            <span className="text-[10px] text-gray-500">1:24</span>
            <div className="flex-1 h-1 bg-white/10 rounded-full relative cursor-pointer overflow-hidden">
              <div 
                className="absolute top-0 left-0 h-full bg-violet-500 rounded-full group-hover:bg-violet-400" 
                style={{ width: `${progress}%` }} 
              />
            </div>
            <span className="text-[10px] text-gray-500">{song.duration}</span>
          </div>
        </div>

        {/* Extra Tools */}
        <div className="flex items-center gap-4 w-1/3 justify-end">
          <Share2 className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer" />
          
          <div className="relative group">
             <button 
                onClick={() => accountType === UserAccountType.FREE ? onUpgrade() : console.log('Downloading...')}
                className={`p-2 rounded-full transition-colors ${accountType === UserAccountType.FREE ? 'text-gray-600' : 'text-gray-400 hover:text-white hover:bg-white/10'}`}
              >
                <Download className="w-5 h-5" />
              </button>
              {accountType === UserAccountType.FREE && (
                <div className="absolute bottom-full right-0 mb-2 w-32 bg-black/90 text-[10px] p-2 rounded hidden group-hover:block border border-white/20">
                  Available for Primary Users only
                </div>
              )}
          </div>

          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-gray-400" />
            <div className="w-20 h-1 bg-white/10 rounded-full overflow-hidden">
              <div className="w-2/3 h-full bg-white/40" />
            </div>
          </div>
        </div>

      </div>
      
      {accountType === UserAccountType.FREE && (
        <div className="text-[10px] text-center text-violet-400 mt-2 font-medium tracking-wider">
           FREE ACCOUNT - WATCH ADS TO UNLOCK OFFLINE MODE
        </div>
      )}
    </div>
  );
};

export default MusicPlayer;
