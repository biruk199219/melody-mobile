
import React from 'react';
import { Home, Search, Library, PlusSquare, Heart, Settings, User, Headphones, LogOut } from 'lucide-react';
import { UserAccountType } from '../types';

interface SidebarProps {
  onLogout: () => void;
  accountType: UserAccountType;
}

const Sidebar: React.FC<SidebarProps> = ({ onLogout, accountType }) => {
  const NavItem = ({ icon: Icon, label, active = false }: { icon: any, label: string, active?: boolean }) => (
    <div className={`flex items-center gap-4 py-3 px-4 rounded-xl cursor-pointer transition-all duration-200 group ${active ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
      <Icon className={`w-5 h-5 ${active ? 'text-violet-500' : 'group-hover:text-violet-400'}`} />
      <span className="font-medium">{label}</span>
    </div>
  );

  return (
    <div className="w-64 h-screen flex flex-col p-6 sticky top-0 overflow-y-auto">
      <div className="flex items-center gap-3 mb-10 px-4">
        <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-fuchsia-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/20">
          <Headphones className="text-white w-6 h-6" />
        </div>
        <h1 className="text-xl font-black tracking-tighter">MELODY<span className="text-violet-500">HUB</span></h1>
      </div>

      <div className="space-y-1 mb-8">
        <NavItem icon={Home} label="Home" active />
        <NavItem icon={Search} label="Discover" />
        <NavItem icon={Library} label="Your Library" />
      </div>

      <div className="mb-8">
        <h3 className="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4">Personal</h3>
        <div className="space-y-1">
          <NavItem icon={PlusSquare} label="Create Playlist" />
          <NavItem icon={Heart} label="Liked Songs" />
        </div>
      </div>

      <div className="mt-auto pt-6 border-t border-white/5 space-y-1">
        <div className="p-4 rounded-2xl bg-gradient-to-br from-violet-900/40 to-fuchsia-900/40 border border-violet-500/20 mb-4 group cursor-pointer hover:border-violet-500/50 transition-all">
          <p className="text-xs font-bold text-violet-400 mb-1 uppercase tracking-wider">
            {accountType === UserAccountType.FREE ? 'Free Account' : 'Primary Account'}
          </p>
          <p className="text-xs text-gray-400">
            {accountType === UserAccountType.FREE ? 'Enjoy music with ads' : 'HD Quality & Downloads active'}
          </p>
          {accountType === UserAccountType.FREE && (
             <button className="mt-3 w-full py-2 bg-violet-600 hover:bg-violet-500 text-white text-[10px] font-black rounded-lg transition-colors">UPGRADE TO PRO</button>
          )}
        </div>
        
        <NavItem icon={Settings} label="Settings" />
        <div onClick={onLogout}>
           <NavItem icon={LogOut} label="Logout" />
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
