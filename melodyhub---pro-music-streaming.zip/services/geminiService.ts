
import { GoogleGenAI } from "@google/genai";

export const getSongDescription = async (songTitle: string, artistName: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a short, poetic, 2-sentence musical insight or "vibe" description for the song "${songTitle}" by "${artistName}". Mention its mood.`,
      config: {
        maxOutputTokens: 100,
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "A unique blend of rhythm and soul that resonates with the spirit.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "A beautiful composition waiting to be explored.";
  }
};
