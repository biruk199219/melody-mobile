
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import HeroCarousel from './components/HeroCarousel';
import MusicPlayer from './components/MusicPlayer';
import { Song, UserAccountType, User } from './types';
import { GENRES, MOCK_SONGS } from './constants';
import { Star, MoreHorizontal, Download, Play, MessageCircle, Info } from 'lucide-react';
import { getSongDescription } from './services/geminiService';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentSong, setCurrentSong] = useState<Song | null>(MOCK_SONGS[0]);
  const [songInsight, setSongInsight] = useState<string>('');
  const [activeTab, setActiveTab] = useState('Pop');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(true);
  const [emailInput, setEmailInput] = useState('');
  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);

  // Gemini AI insight effect
  useEffect(() => {
    if (currentSong) {
      setSongInsight('Generating AI vibes...');
      getSongDescription(currentSong.title, currentSong.artist).then(setSongInsight);
    }
  }, [currentSong]);

  const handleLogin = () => {
    if (!emailInput) return;
    setUser({
      id: '1',
      email: emailInput,
      type: UserAccountType.FREE,
      followedArtists: [],
      likedSongs: []
    });
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthModalOpen(true);
  };

  const upgradeAccount = () => {
    if (user) {
      setUser({ ...user, type: UserAccountType.PRIMARY });
      setIsUpgradeOpen(false);
    }
  };

  if (isAuthModalOpen && !user) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black">
        <div className="w-full max-w-md p-8 glass rounded-3xl border border-white/20 shadow-2xl">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-violet-600 rounded-2xl flex items-center justify-center">
              <Star className="text-white w-8 h-8 fill-white" />
            </div>
          </div>
          <h2 className="text-3xl font-black text-center mb-2">Welcome to MelodyHub</h2>
          <p className="text-gray-400 text-center mb-8">Sign in with your email to start listening</p>
          <div className="space-y-4">
            <input 
              type="email" 
              placeholder="Email address" 
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-violet-500 transition-colors"
            />
            <button 
              onClick={handleLogin}
              className="w-full bg-white text-black font-bold py-3 rounded-xl hover:bg-gray-200 transition-transform active:scale-95"
            >
              Continue with Email
            </button>
          </div>
          <p className="text-[10px] text-gray-500 text-center mt-6 uppercase tracking-widest">Secure • Ad-Supported • Free to Start</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#0a0a0a] text-white selection:bg-violet-500/30">
      <Sidebar onLogout={handleLogout} accountType={user?.type || UserAccountType.FREE} />

      <main className="flex-1 px-8 py-6 pb-32">
        {/* Top Header */}
        <div className="flex items-center justify-between mb-8">
           <div className="flex items-center gap-4 bg-white/5 p-1 rounded-full pl-4 pr-1">
              <span className="text-sm font-medium text-gray-400">Trending Now</span>
              <div className="bg-violet-600 px-3 py-1 rounded-full text-xs font-bold animate-pulse">LIVE</div>
           </div>
           <div className="flex items-center gap-4">
              {user?.type === UserAccountType.FREE && (
                <button 
                  onClick={() => setIsUpgradeOpen(true)}
                  className="px-4 py-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-full text-xs font-bold hover:shadow-lg hover:shadow-violet-500/20 transition-all"
                >
                  UPGRADE
                </button>
              )}
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-gray-700 to-gray-500 flex items-center justify-center border border-white/10">
                <span className="text-xs font-bold uppercase">{user?.email.substring(0, 2)}</span>
              </div>
           </div>
        </div>

        <HeroCarousel />

        {/* AI Insight Section */}
        {currentSong && (
          <div className="mb-10 p-6 glass rounded-2xl border-l-4 border-l-violet-500 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
               <Star className="w-16 h-16 fill-violet-500" />
            </div>
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-violet-500/20 p-1 rounded">
                <Info className="w-4 h-4 text-violet-400" />
              </div>
              <span className="text-[10px] font-black tracking-[0.2em] text-violet-400 uppercase">AI Song Insight</span>
            </div>
            <p className="text-xl font-medium text-gray-100 italic">"{songInsight}"</p>
          </div>
        )}

        {/* Genre Tabs */}
        <div className="flex gap-4 mb-8 overflow-x-auto pb-2 scrollbar-hide">
          {GENRES.map((genre) => (
            <button
              key={genre}
              onClick={() => setActiveTab(genre)}
              className={`whitespace-nowrap px-6 py-2 rounded-full font-semibold text-sm transition-all ${
                activeTab === genre 
                ? 'bg-white text-black shadow-xl' 
                : 'bg-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              {genre}
            </button>
          ))}
        </div>

        {/* Main Grid View */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-black">{activeTab} Favorites</h3>
            <span className="text-sm text-violet-500 font-bold cursor-pointer hover:underline">See all</span>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {MOCK_SONGS.filter(s => s.genre === activeTab || activeTab === 'Others').map((song) => (
              <div 
                key={song.id} 
                className="group relative bg-white/5 p-4 rounded-2xl hover:bg-white/10 transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border border-transparent hover:border-white/10"
                onClick={() => setCurrentSong(song)}
              >
                <div className="relative aspect-square mb-4 overflow-hidden rounded-xl">
                  <img src={song.cover} alt={song.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center transform translate-y-4 group-hover:translate-y-0 transition-transform shadow-2xl">
                       <Play className="w-6 h-6 fill-black text-black ml-1" />
                    </div>
                  </div>
                </div>
                <h4 className="font-bold truncate group-hover:text-violet-400 transition-colors">{song.title}</h4>
                <p className="text-xs text-gray-500 truncate">{song.artist}</p>
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                    <span className="text-[10px] font-bold text-gray-400">{song.rating}</span>
                  </div>
                  <div className="flex gap-2">
                    <MessageCircle className="w-3 h-3 text-gray-500 hover:text-white" />
                    <MoreHorizontal className="w-3 h-3 text-gray-500 hover:text-white" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Top 50 Carousel - Simpler List */}
        <section>
          <h3 className="text-2xl font-black mb-6">Top 1–50 Playlist</h3>
          <div className="space-y-2">
            {MOCK_SONGS.slice(0, 5).map((song, i) => (
              <div key={song.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors group">
                <span className="w-6 text-center text-sm font-bold text-gray-600 group-hover:text-violet-500">{i + 1}</span>
                <img src={song.cover} className="w-12 h-12 rounded-lg" />
                <div className="flex-1">
                  <h4 className="font-bold text-sm">{song.title}</h4>
                  <p className="text-xs text-gray-500">{song.artist}</p>
                </div>
                <div className="hidden md:block text-xs text-gray-500 font-medium px-4">{song.genre}</div>
                <div className="flex items-center gap-6">
                  <span className="text-xs text-gray-500 font-mono">{song.duration}</span>
                  <button 
                    disabled={user?.type === UserAccountType.FREE}
                    className={`p-2 rounded-full transition-all ${user?.type === UserAccountType.FREE ? 'text-gray-800' : 'text-gray-400 hover:text-white hover:bg-white/10'}`}
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Upgrade Modal */}
      {isUpgradeOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-xl p-8 glass-dark rounded-3xl border border-white/20 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-violet-600 via-fuchsia-600 to-violet-600" />
            <h2 className="text-4xl font-black mb-4">Go <span className="text-violet-500">Primary</span></h2>
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="space-y-4">
                <p className="text-sm font-bold text-violet-400">BENEFITS</p>
                <ul className="space-y-3 text-sm text-gray-300">
                  <li className="flex items-center gap-2">✓ Offline Mode & Downloads</li>
                  <li className="flex items-center gap-2">✓ HD High Quality Audio</li>
                  <li className="flex items-center gap-2">✓ No Interruption Ads</li>
                  <li className="flex items-center gap-2">✓ Early Album Access</li>
                </ul>
              </div>
              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 flex flex-col justify-center items-center">
                <p className="text-gray-400 text-sm mb-1">Monthly Plan</p>
                <h3 className="text-3xl font-black mb-4">$9.99/mo</h3>
                <button onClick={upgradeAccount} className="w-full py-3 bg-white text-black font-black rounded-xl hover:scale-105 transition-transform">UPGRADE NOW</button>
              </div>
            </div>
            <button 
              onClick={() => setIsUpgradeOpen(false)}
              className="w-full py-3 text-gray-500 hover:text-white transition-colors font-bold text-sm"
            >
              Maybe later
            </button>
          </div>
        </div>
      )}

      <MusicPlayer 
        song={currentSong} 
        accountType={user?.type || UserAccountType.FREE} 
        onUpgrade={() => setIsUpgradeOpen(true)}
      />
    </div>
  );
};

export default App;
